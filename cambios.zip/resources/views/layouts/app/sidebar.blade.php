<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('partials.head')
    </head>
    @php $isEntrepreneur = auth()->user()->experience === 'emprendedor'; @endphp
    <body @class([
        'min-h-screen',
        'bg-zinc-50/60 entrepreneur-area dark:bg-zinc-950' => $isEntrepreneur,
        'bg-white dark:bg-zinc-800' => ! $isEntrepreneur,
    ])>
        <div class="min-h-screen lg:flex">
            <flux:sidebar
                sticky
                collapsible="mobile"
                @class([
                    'border-e border-zinc-200 dark:border-zinc-700 dark:bg-zinc-900',
                    'entrepreneur-sidebar !w-64 !gap-2 !bg-white !px-3 !py-4 dark:!bg-zinc-900' => $isEntrepreneur,
                    'bg-zinc-50' => ! $isEntrepreneur,
                ])
            >
                <flux:sidebar.header>
                    <x-app-logo :sidebar="true" href="{{ route('dashboard') }}" wire:navigate />
                    <flux:sidebar.collapse class="lg:hidden" />
                </flux:sidebar.header>

                <flux:sidebar.nav>
                    @if (auth()->user()->experience === 'cliente')
                        @include('layouts.app.nav-cliente')
                    @elseif (auth()->user()->experience === 'emprendedor')
                        @include('layouts.app.nav-emprendedor')
                    @else
                        <flux:sidebar.group :heading="__('Merkamigo')" class="grid">
                            <flux:sidebar.item icon="home" :href="route('dashboard')" :current="request()->routeIs('dashboard')" wire:navigate>
                                {{ __('Elegir experiencia') }}
                            </flux:sidebar.item>
                        </flux:sidebar.group>
                    @endif
                </flux:sidebar.nav>

                <flux:spacer />

                @unless ($isEntrepreneur)
                    <x-desktop-user-menu class="hidden lg:block" />
                @endunless
            </flux:sidebar>

            <div class="min-w-0 flex-1">
                @if ($isEntrepreneur)
                    <header class="entrepreneur-topbar sticky top-0 z-10 hidden h-14 items-center justify-end gap-3 border-b border-zinc-200 bg-white/95 px-6 backdrop-blur lg:flex dark:border-zinc-700 dark:bg-zinc-900/95">
                        <a href="{{ route('messages.index') }}" wire:navigate class="relative inline-flex size-9 items-center justify-center rounded-full text-zinc-500 transition hover:bg-zinc-100 hover:text-zinc-900 dark:hover:bg-zinc-800 dark:hover:text-white" aria-label="{{ __('Mensajes') }}">
                            <flux:icon.chat-bubble-left-right class="size-5" variant="outline" />
                            @if (auth()->user()->unreadBusinessMessagesCount() > 0)
                                <span class="absolute right-1 top-1 size-2 rounded-full bg-brand-500 ring-2 ring-white dark:ring-zinc-900"></span>
                            @endif
                        </a>
                        {{--
                            Pedido del usuario (2026-10-11): en la zona de
                            emprendedores la campanita solo navegaba a
                            "Actividad" — ahora despliega la misma
                            ventana de notificaciones que ya existe en
                            cliente (`<livewire:notification-bell>`),
                            reutilizada tal cual en vez de duplicar su
                            lógica de marcar-como-leída/redirigir acá.
                        --}}
                        <livewire:notification-bell />
                        <x-desktop-user-menu placement="header" />
                    </header>
                @endif

                <!-- Mobile User Menu -->
                <flux:header data-app-header class="lg:hidden">
                    <flux:sidebar.toggle class="lg:hidden" icon="bars-2" inset="left" />

                    <flux:spacer />

                    <flux:dropdown position="top" align="end">
                        <flux:profile
                            :avatar="auth()->user()->avatarUrl()"
                            :initials="auth()->user()->initials()"
                            circle
                            icon-trailing="chevron-down"
                        />

                        <flux:menu>
                            <flux:menu.radio.group>
                                <div class="p-0 text-sm font-normal">
                                    <div class="flex items-center gap-2 px-1 py-1.5 text-start text-sm">
                                        <flux:avatar
                                            :src="auth()->user()->avatarUrl()"
                                            :name="auth()->user()->name"
                                            :initials="auth()->user()->initials()"
                                            circle
                                        />

                                        <div class="grid flex-1 text-start text-sm leading-tight">
                                            <flux:heading class="truncate">{{ auth()->user()->name }}</flux:heading>
                                            <flux:text class="truncate">{{ auth()->user()->email }}</flux:text>
                                        </div>
                                    </div>
                                </div>
                            </flux:menu.radio.group>

                            <flux:menu.separator />

                            <x-experience-switch-menu />

                            <flux:menu.separator />

                            <flux:menu.radio.group>
                                <flux:menu.item :href="route('clientes.favoritos')" icon="heart" wire:navigate>
                                    {{ __('Favoritos') }}
                                </flux:menu.item>
                                <flux:menu.item :href="route('profile.edit')" icon="cog" wire:navigate>
                                    {{ __('Configuración') }}
                                </flux:menu.item>
                            </flux:menu.radio.group>

                            <flux:menu.separator />

                            <form method="POST" action="{{ route('logout') }}" class="w-full">
                                @csrf
                                <flux:menu.item
                                    as="button"
                                    type="submit"
                                    icon="arrow-right-start-on-rectangle"
                                    class="w-full cursor-pointer"
                                    data-test="logout-button"
                                >
                                    {{ __('Cerrar sesión') }}
                                </flux:menu.item>
                            </form>
                        </flux:menu>
                    </flux:dropdown>
                </flux:header>
                <x-app-install />

                <div class="{{ auth()->user()->experience === 'cliente' ? 'pb-20 md:pb-0' : '' }}">
                    @if (session(\App\Domain\Platform\Actions\StartUserImpersonation::SESSION_KEY))
                        <div class="col-span-full w-full border-b border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-100">
                            <div class="flex w-full flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    Estás usando la cuenta de <strong>{{ auth()->user()->name }}</strong> como soporte.
                                    Volverás a <strong>{{ data_get(session(\App\Domain\Platform\Actions\StartUserImpersonation::SESSION_KEY), 'impersonator_name', 'tu cuenta de superadmin') }}</strong> cuando cierres este modo.
                                </div>

                                <form method="POST" action="{{ route('impersonation.stop') }}">
                                    @csrf
                                    <flux:button type="submit" variant="filled" size="sm">
                                        Volver a mi cuenta
                                    </flux:button>
                                </form>
                            </div>
                        </div>
                    @endif

                    {{ $slot }}
                </div>
            </div>
        </div>

        @if (\App\Support\Navigation\ClientBottomNav::visible())
            <x-cliente-bottom-nav />
        @endif

        @if ($showChatWidget ?? true)
            <x-storefront-chat-widget
                :with-sound="false"
                character-gif="images/chatbot-merkamiga-IA.gif"
                character-frame1="images/chatbot-merkamiga-IA-frame1.png"
                :mode="auth()->user()->experience === 'emprendedor' ? 'emprendedor' : 'general'"
                :above-mobile-bottom-nav="\App\Support\Navigation\ClientBottomNav::visible()"
            />
        @endif

        @persist('toast')
            <flux:toast.group>
                <flux:toast />
            </flux:toast.group>
        @endpersist

        @stack('scripts')
        @fluxScripts
    </body>
</html>
