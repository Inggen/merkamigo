<?php

namespace App\Domain\Storefronts\Actions;

use App\Domain\Businesses\Models\Business;
use App\Domain\Platform\Actions\RecordAuditLog;
use App\Domain\Storefronts\Jobs\SyncProductToGoogleMerchant;
use App\Domain\Storefronts\Models\Storefront;
use App\Models\User;
use App\Support\Media\MediaUploader;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

/**
 * Actualiza los datos editables de negocio + vitrina. La usan los pasos
 * 1-3 de "Mi Merkamigo en cinco minutos" (autosave) y el editor de vitrina
 * del panel (`/emprendedores/negocios/{business}/vitrina`), sin duplicar
 * reglas (0.4 del TODO).
 */
class UpdateStorefront
{
    private const BUSINESS_FIELDS = [
        'name', 'zone', 'address', 'latitude', 'longitude', 'has_physical_location',
        'google_business_store_code', 'municipality_id', 'category_id',
        'whatsapp_number', 'contact_channel', 'hours', 'social_links', 'payment_info', 'attributes', 'logo_alt_text',
    ];

    private const STOREFRONT_FIELDS = [
        'headline', 'description', 'cover_alt_text', 'stand_color',
        'show_posts', 'show_reels', 'google_maps_embed_url',
    ];

    /**
     * @param  array<string, mixed>  $data
     */
    public function handle(Business $business, array $data, User $actor): Storefront
    {
        $validated = Validator::make($data, [
            'name' => ['sometimes', 'string', 'max:255'],
            'zone' => ['sometimes', 'nullable', 'string', 'max:255'],
            'address' => ['sometimes', 'nullable', 'string', 'max:255'],
            'latitude' => ['sometimes', 'nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['sometimes', 'nullable', 'numeric', 'between:-180,180'],
            // Terreno para inventario local de Google Merchant (ver
            // TODO-Google-Merchant.md, post-cierre): lo marca el propio
            // negocio, nunca se infiere. `google_business_store_code` es
            // el store_code de SU PROPIO Perfil de Empresa de Google.
            'has_physical_location' => ['sometimes', 'boolean'],
            'google_business_store_code' => ['sometimes', 'nullable', 'string', 'max:64'],
            'municipality_id' => ['sometimes', 'nullable', 'integer', 'exists:municipalities,id'],
            'category_id' => ['sometimes', 'nullable', 'integer', 'exists:categories,id'],
            'whatsapp_number' => ['sometimes', 'nullable', 'string', 'max:20'],
            'contact_channel' => ['sometimes', 'string', 'in:merkamigo,whatsapp,phone,external_link'],
            'hours' => ['sometimes', 'nullable', 'array'],
            'social_links' => ['sometimes', 'nullable', 'array'],
            'social_links.website' => ['nullable', 'url:http,https', 'max:2048'],
            'payment_info' => ['sometimes', 'nullable', 'string'],
            'attributes' => ['sometimes', 'nullable', 'array'],
            'payment_method_ids' => ['sometimes', 'nullable', 'array'],
            'payment_method_ids.*' => ['integer', 'exists:payment_methods,id'],
            'headline' => ['sometimes', 'nullable', 'string', 'max:255'],
            'description' => ['sometimes', 'nullable', 'string'],
            'show_posts' => ['sometimes', 'boolean'],
            'show_reels' => ['sometimes', 'boolean'],
            'google_maps_embed_url' => [
                'sometimes',
                'nullable',
                'string',
                'max:5000',
                function (string $attribute, mixed $value, \Closure $fail): void {
                    if (filled($value) && Storefront::normalizeGoogleMapsEmbedUrl((string) $value) === null) {
                        $fail(__('Usa el código iframe o enlace de inserción generado por Google Maps.'));
                    }
                },
            ],
            'logo' => ['sometimes', 'nullable'],
            'remove_logo' => ['sometimes', 'boolean'],
            'logo_alt_text' => ['sometimes', 'nullable', 'string', 'max:255'],
            'cover' => ['sometimes', 'nullable'],
            'remove_cover' => ['sometimes', 'boolean'],
            'cover_alt_text' => ['sometimes', 'nullable', 'string', 'max:255'],
            // Color del stand en la plaza inmersiva 3D, elegido libremente
            // por el emprendedor — formato exacto que ya produce
            // <input type="color"> (#rrggbb, sin abreviatura ni alpha).
            'stand_color' => ['sometimes', 'nullable', 'string', 'regex:/^#[0-9A-Fa-f]{6}$/'],
        ])->validate();

        return DB::transaction(function () use ($business, $validated, $actor) {
            $business->fill(Arr::only($validated, self::BUSINESS_FIELDS));

            if ($validated['remove_logo'] ?? false) {
                app(MediaUploader::class)->delete($business->logo_path);
                $business->logo_path = null;
            } elseif (! empty($validated['logo']) && $validated['logo'] instanceof UploadedFile) {
                app(MediaUploader::class)->delete($business->logo_path);
                $business->logo_path = app(MediaUploader::class)->store(
                    $validated['logo'],
                    'business_logo',
                    "businesses/{$business->id}",
                );
            }

            $merchantChanged = $business->isDirty(['name', 'category_id', 'has_physical_location', 'google_business_store_code']);
            $business->save();

            if (array_key_exists('payment_method_ids', $validated)) {
                $business->paymentMethods()->sync($validated['payment_method_ids'] ?? []);
            }

            $storefront = $business->storefront;
            if (array_key_exists('google_maps_embed_url', $validated)) {
                $validated['google_maps_embed_url'] = Storefront::normalizeGoogleMapsEmbedUrl($validated['google_maps_embed_url']);
            }
            $storefront->fill(Arr::only($validated, self::STOREFRONT_FIELDS));

            if ($validated['remove_cover'] ?? false) {
                app(MediaUploader::class)->delete($storefront->cover_path);
                $storefront->cover_path = null;
            } elseif (! empty($validated['cover']) && $validated['cover'] instanceof UploadedFile) {
                app(MediaUploader::class)->delete($storefront->cover_path);
                $storefront->cover_path = app(MediaUploader::class)->store(
                    $validated['cover'],
                    'storefront_cover',
                    "storefronts/{$storefront->id}",
                );
            }

            $merchantChanged = $merchantChanged || $storefront->isDirty('description');
            $storefront->save();

            if ($merchantChanged && config('services.google_merchant.enabled')) {
                $business->products()->where('type', 'producto')->pluck('id')
                    ->each(fn (int $id) => SyncProductToGoogleMerchant::dispatch($id)->afterCommit());
            }

            app(RecordAuditLog::class)->handle($actor, 'business.updated', $business);

            return $storefront->setRelation('business', $business);
        });
    }
}
