<?php

namespace Tests\Feature\Storefronts;

use App\Domain\Businesses\Models\BusinessMembership;
use App\Domain\Discovery\Models\Category;
use App\Domain\Discovery\Models\Municipality;
use App\Domain\Storefronts\Actions\CreateProduct;
use App\Domain\Storefronts\Actions\CreateStorefront;
use App\Domain\Storefronts\Actions\UpdateStorefront;
use App\Domain\Storefronts\Jobs\DeleteProductFromGoogleMerchant;
use App\Domain\Storefronts\Jobs\SyncProductToGoogleMerchant;
use App\Domain\Storefronts\Models\Product;
use App\Models\User;
use App\Support\GoogleMerchant\GoogleMerchantClient;
use App\Support\GoogleMerchant\GoogleMerchantProductMapper;
use App\Support\GoogleMerchant\GoogleMerchantService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\Request;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Queue;
use Tests\TestCase;

/**
 * Escenarios 7, 9, 10, 11 y 13 de la Fase 11 — todos con
 * `GoogleMerchantClient` atado a un resolver de token FALSO (nunca el
 * real, resuelto por el contenedor con las credenciales de este
 * entorno) y `Http::fake()`, para no llamar nunca a Google de verdad.
 */
class GoogleMerchantServiceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->app->bind(GoogleMerchantClient::class, fn ($app) => new GoogleMerchantClient(
            $app->make(GoogleMerchantProductMapper::class),
            fn (): string => 'test-access-token',
        ));

        config()->set('services.google_merchant.enabled', true);
        config()->set('services.google_merchant.account_id', '123456');
        config()->set('services.google_merchant.data_source_id', '789');
        config()->set('services.google_merchant.endpoint', 'https://merchantapi.googleapis.com');
    }

    public function test_price_update_triggers_a_resync(): void
    {
        Http::fake(['*productInputs:insert*' => Http::response(['name' => 'x'], 200)]);

        $product = $this->product();
        $service = app(GoogleMerchantService::class);

        $service->syncProduct($product);
        $this->assertSame('publicado', $product->fresh()->google_merchant_status);

        $product->update(['price' => 99000]);
        $service->syncProduct($product->fresh());

        Http::assertSentCount(2);
    }

    public function test_unchanged_product_does_not_call_google_again(): void
    {
        Http::fake(['*productInputs:insert*' => Http::response(['name' => 'x'], 200)]);

        $product = $this->product();
        $service = app(GoogleMerchantService::class);

        $service->syncProduct($product);
        $service->syncProduct($product->fresh());

        Http::assertSentCount(1);
    }

    public function test_a_previously_published_product_that_becomes_ineligible_is_deleted_from_google(): void
    {
        Http::fake([
            '*productInputs:insert*' => Http::response(['name' => 'x'], 200),
            '*productInputs/*' => Http::response([], 200),
        ]);

        $product = $this->product();
        $service = app(GoogleMerchantService::class);

        $service->syncProduct($product);
        $this->assertSame('publicado', $product->fresh()->google_merchant_status);

        $product->update(['status' => 'archivado']);
        $service->syncProduct($product->fresh());

        Http::assertSent(fn (Request $request) => $request->method() === 'DELETE');
        $this->assertSame('no_publicado', $product->fresh()->google_merchant_status);
    }

    public function test_a_temporary_google_error_is_rethrown_and_does_not_mark_the_product_as_failed(): void
    {
        Http::fake(['*productInputs:insert*' => Http::response(['error' => ['message' => 'backend error']], 503)]);

        $product = $this->product();

        $this->expectException(RequestException::class);

        try {
            app(GoogleMerchantService::class)->syncProduct($product);
        } finally {
            $this->assertSame('no_publicado', $product->fresh()->google_merchant_status);
        }
    }

    public function test_a_permanent_google_error_is_recorded_without_rethrowing(): void
    {
        Http::fake(['*productInputs:insert*' => Http::response(['error' => ['message' => 'invalidArgument productAttributes.price']], 400)]);

        $product = $this->product();

        app(GoogleMerchantService::class)->syncProduct($product);

        $product->refresh();
        $this->assertSame('error', $product->google_merchant_status);
        $this->assertStringContainsString('price', $product->google_merchant_last_error);
    }

    /**
     * `GOOGLE_MERCHANT_LOCAL_INVENTORY_ENABLED` apaga por defecto — un
     * negocio con local físico y store_code configurados NO debe generar
     * una llamada a `localInventories:insert` mientras el flag global
     * siga en false (TODO-Google-Merchant.md, post-cierre).
     */
    public function test_local_inventory_is_never_pushed_while_the_feature_flag_is_off(): void
    {
        Http::fake([
            '*productInputs:insert*' => Http::response(['name' => 'x'], 200),
            '*localInventories:insert*' => Http::response(['name' => 'x'], 200),
        ]);

        $product = $this->product();
        $product->business->update([
            'has_physical_location' => true,
            'google_business_store_code' => 'tienda-1',
        ]);

        app(GoogleMerchantService::class)->syncProduct($product->fresh(['business.storefront', 'business.category', 'media']));

        Http::assertNotSent(fn (Request $request) => str_contains((string) $request->url(), 'localInventories'));
    }

    public function test_local_inventory_is_pushed_once_the_flag_and_the_business_are_both_ready(): void
    {
        config()->set('services.google_merchant.local_inventory_enabled', true);

        Http::fake([
            '*productInputs:insert*' => Http::response(['name' => 'x'], 200),
            '*localInventories:insert*' => Http::response(['name' => 'y'], 200),
        ]);

        $product = $this->product();
        $product->business->update([
            'has_physical_location' => true,
            'google_business_store_code' => 'tienda-1',
        ]);

        app(GoogleMerchantService::class)->syncProduct($product->fresh(['business.storefront', 'business.category', 'media']));

        Http::assertSent(fn (Request $request) => str_contains((string) $request->url(), 'localInventories:insert')
            && $request['storeCode'] === 'tienda-1');
    }

    public function test_jobs_are_configured_to_retry_with_backoff(): void
    {
        $syncJob = new SyncProductToGoogleMerchant(1);
        $deleteJob = new DeleteProductFromGoogleMerchant(1);

        $this->assertSame(5, $syncJob->tries);
        $this->assertSame(5, $deleteJob->tries);
        $this->assertNotEmpty($syncJob->backoff());
        $this->assertNotEmpty($deleteJob->backoff());
    }

    public function test_local_inventory_is_retried_without_resending_the_online_product(): void
    {
        config()->set('services.google_merchant.local_inventory_enabled', true);
        Http::fake([
            '*productInputs:insert*' => Http::response(['name' => 'online'], 200),
            '*localInventories:insert*' => Http::sequence()->push([], 503)->push([], 503)->push(['name' => 'local'], 200),
        ]);
        $product = $this->product();
        $product->business->update(['has_physical_location' => true, 'google_business_store_code' => 'real-store']);
        $service = app(GoogleMerchantService::class);
        try {
            $service->syncProduct($product->fresh(['business.storefront', 'business.category', 'media']));
            $this->fail('A temporary inventory failure must trigger a queue retry.');
        } catch (RequestException $exception) {
            $this->assertSame(503, $exception->response->status());
        }
        $service->syncProduct($product->fresh(['business.storefront', 'business.category', 'media']));
        $this->assertSame('publicado', $product->fresh()->google_merchant_status);
        Http::assertSentCount(4);
        $this->assertCount(1, Http::recorded(fn (Request $r) => str_contains($r->url(), 'productInputs:insert')));
    }

    public function test_store_code_changes_queue_products_but_unrelated_edits_do_not(): void
    {
        $product = $this->product();
        $business = $product->business;
        $actor = BusinessMembership::where('business_id', $business->id)->firstOrFail()->user;
        Queue::fake();
        app(UpdateStorefront::class)->handle($business, ['zone' => 'Centro'], $actor);
        Queue::assertNothingPushed();
        app(UpdateStorefront::class)->handle($business, ['google_business_store_code' => 'store-2'], $actor);
        Queue::assertPushed(SyncProductToGoogleMerchant::class, 1);
    }

    private function product(): Product
    {
        $municipality = Municipality::firstOrCreate(
            ['slug' => 'cajica'],
            ['name' => 'Cajicá', 'department' => 'Cundinamarca', 'is_active' => true],
        );
        $category = Category::firstOrCreate(
            ['slug' => 'alimentos'],
            ['name' => 'Alimentos', 'is_active' => true],
        );
        $owner = User::factory()->create();
        $storefront = app(CreateStorefront::class)->handle($owner, [
            'name' => 'Negocio de servicio '.uniqid(),
            'whatsapp_number' => '+573001112233',
            'municipality_id' => $municipality->id,
            'category_id' => $category->id,
        ]);
        $business = $storefront->business;
        $business->update(['status' => 'publicado', 'google_merchant_enabled' => true]);

        $product = app(CreateProduct::class)->handle($business, [
            'name' => 'Producto de servicio',
            'description' => 'Descripción de prueba.',
            'type' => 'producto',
            'price_type' => 'exacto',
            'price' => 18000,
        ], [], $owner);
        $product->update(['status' => 'publicado']);
        $product->media()->create(['path' => 'products/test.jpg', 'position' => 0]);

        return $product->fresh(['business.storefront', 'business.category', 'media']);
    }
}
