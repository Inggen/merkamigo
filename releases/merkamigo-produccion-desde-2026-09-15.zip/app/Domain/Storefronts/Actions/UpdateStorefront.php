<?php

namespace App\Domain\Storefronts\Actions;

use App\Domain\Businesses\Models\Business;
use App\Domain\Platform\Actions\RecordAuditLog;
use App\Domain\Storefronts\Models\Storefront;
use App\Models\User;
use App\Support\Media\MediaUploader;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

/**
 * Actualiza los datos editables de negocio + vitrina. La usan los pasos
 * 1-3 de "Mi Merkamigo en cinco minutos" (autosave) y el editor de vitrina
 * del panel (`/emprendedores/negocios/{business}/vitrina`), sin duplicar
 * reglas (0.4 del TODO).
 */
class UpdateStorefront
{
    private const BUSINESS_FIELDS = [
        'name', 'zone', 'address', 'latitude', 'longitude', 'has_physical_location',
        'google_business_store_code', 'municipality_id', 'category_id',
        'whatsapp_number', 'hours', 'social_links', 'payment_info', 'attributes', 'logo_alt_text',
    ];

    private const STOREFRONT_FIELDS = ['headline', 'description', 'cover_alt_text', 'stand_color'];

    /**
     * @param  array<string, mixed>  $data
     */
    public function handle(Business $business, array $data, User $actor): Storefront
    {
        $validated = Validator::make($data, [
            'name' => ['sometimes', 'string', 'max:255'],
            'zone' => ['sometimes', 'nullable', 'string', 'max:255'],
            'address' => ['sometimes', 'nullable', 'string', 'max:255'],
            'latitude' => ['sometimes', 'nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['sometimes', 'nullable', 'numeric', 'between:-180,180'],
            // Terreno para inventario local de Google Merchant (ver
            // TODO-Google-Merchant.md, post-cierre): lo marca el propio
            // negocio, nunca se infiere. `google_business_store_code` es
            // el store_code de SU PROPIO Perfil de Empresa de Google.
            'has_physical_location' => ['sometimes', 'boolean'],
            'google_business_store_code' => ['sometimes', 'nullable', 'string', 'max:64'],
            'municipality_id' => ['sometimes', 'nullable', 'integer', 'exists:municipalities,id'],
            'category_id' => ['sometimes', 'nullable', 'integer', 'exists:categories,id'],
            'whatsapp_number' => ['sometimes', 'nullable', 'string', 'max:20'],
            'hours' => ['sometimes', 'nullable', 'array'],
            'social_links' => ['sometimes', 'nullable', 'array'],
            'payment_info' => ['sometimes', 'nullable', 'string'],
            'attributes' => ['sometimes', 'nullable', 'array'],
            'payment_method_ids' => ['sometimes', 'nullable', 'array'],
            'payment_method_ids.*' => ['integer', 'exists:payment_methods,id'],
            'headline' => ['sometimes', 'nullable', 'string', 'max:255'],
            'description' => ['sometimes', 'nullable', 'string'],
            'logo' => ['sometimes', 'nullable'],
            'remove_logo' => ['sometimes', 'boolean'],
            'logo_alt_text' => ['sometimes', 'nullable', 'string', 'max:255'],
            'cover' => ['sometimes', 'nullable'],
            'remove_cover' => ['sometimes', 'boolean'],
            'cover_alt_text' => ['sometimes', 'nullable', 'string', 'max:255'],
            // Color del stand en la plaza inmersiva 3D, elegido libremente
            // por el emprendedor — formato exacto que ya produce
            // <input type="color"> (#rrggbb, sin abreviatura ni alpha).
            'stand_color' => ['sometimes', 'nullable', 'string', 'regex:/^#[0-9A-Fa-f]{6}$/'],
        ])->validate();

        return DB::transaction(function () use ($business, $validated, $actor) {
            $business->fill(Arr::only($validated, self::BUSINESS_FIELDS));

            if ($validated['remove_logo'] ?? false) {
                app(MediaUploader::class)->delete($business->logo_path);
                $business->logo_path = null;
            } elseif (! empty($validated['logo']) && $validated['logo'] instanceof UploadedFile) {
                app(MediaUploader::class)->delete($business->logo_path);
                $business->logo_path = app(MediaUploader::class)->store(
                    $validated['logo'],
                    'business_logo',
                    "businesses/{$business->id}",
                );
            }

            $business->save();

            if (array_key_exists('payment_method_ids', $validated)) {
                $business->paymentMethods()->sync($validated['payment_method_ids'] ?? []);
            }

            $storefront = $business->storefront;
            $storefront->fill(Arr::only($validated, self::STOREFRONT_FIELDS));

            if ($validated['remove_cover'] ?? false) {
                app(MediaUploader::class)->delete($storefront->cover_path);
                $storefront->cover_path = null;
            } elseif (! empty($validated['cover']) && $validated['cover'] instanceof UploadedFile) {
                app(MediaUploader::class)->delete($storefront->cover_path);
                $storefront->cover_path = app(MediaUploader::class)->store(
                    $validated['cover'],
                    'storefront_cover',
                    "storefronts/{$storefront->id}",
                );
            }

            $storefront->save();

            app(RecordAuditLog::class)->handle($actor, 'business.updated', $business);

            return $storefront->setRelation('business', $business);
        });
    }
}
