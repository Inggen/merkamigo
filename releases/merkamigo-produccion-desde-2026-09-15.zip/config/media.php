<?php

// Límites de archivos por contexto (0.6 del TODO: "validar y limitar
// archivos por tipo, tamaño y cantidad"). `max_width`, `target_extension`
// y `quality` (1.2 del TODO: "optimizar, comprimir y generar variantes
// de imágenes") se aplican en `App\Support\Media\MediaUploader`:
// orienta por EXIF, reduce el ancho si lo excede, nunca agranda, remueve
// metadatos al recodificar y, cuando el servidor soporta WebP, convierte
// automáticamente a ese formato con compresión suave. No aplica a
// `verification_document`, que admite PDF.

return [

    'avatar' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 2048,
        'max_files' => 1,
        'max_width' => 512,
        'target_extension' => 'webp',
        'quality' => 88,
    ],

    'business_logo' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 2048,
        'max_files' => 1,
        'max_width' => 512,
        'target_extension' => 'webp',
        'quality' => 90,
    ],

    'product_photo' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 5120,
        'max_files' => 8,
        'max_width' => 1000,
        'target_extension' => 'webp',
        'quality' => 90,
    ],

    'post_photo' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 5120,
        'max_files' => 10,
        'max_width' => 1600,
        'target_extension' => 'webp',
        'quality' => 88,
    ],

    'post_video' => [
        'mimes' => ['mp4', 'webm', 'mov'],
        'max_kb' => 51200,
        'max_files' => 1,
    ],

    'story_photo' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 5120,
        'max_files' => 1,
        'max_width' => 1280,
        'target_extension' => 'webp',
        'quality' => 86,
    ],

    'storefront_cover' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 5120,
        'max_files' => 1,
        'max_width' => 1920,
        'target_extension' => 'webp',
        'quality' => 86,
    ],

    'municipality_cover' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 5120,
        'max_files' => 1,
        'max_width' => 1920,
        'target_extension' => 'webp',
        'quality' => 86,
    ],

    'municipality_hero_video' => [
        'mimes' => ['mp4', 'webm', 'mov'],
        'max_kb' => 51200,
        'max_files' => 1,
    ],

    'verification_document' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'pdf'],
        'max_kb' => 8192,
        'max_files' => 5,
        'disk' => 'private',
    ],

    'payment_method_logo' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp', 'svg'],
        'max_kb' => 512,
        'max_files' => 1,
    ],

    'chatbot_document' => [
        'mimes' => ['pdf'],
        'max_kb' => 10240,
        'max_files' => 1,
        'disk' => 'private',
    ],

    'immersive_experience_thumbnail' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 3072,
        'max_files' => 1,
        'max_width' => 1280,
        'target_extension' => 'webp',
        'quality' => 86,
    ],

    // Fase 9 del TODO social: archivo de un producto digital (ebook,
    // curso, plantilla...). Disco `private` a propósito — nunca una URL
    // pública permanente, se sirve solo con un `Entitlement` vigente.
    'product_digital_file' => [
        'mimes' => ['pdf', 'zip', 'epub', 'mp4', 'mp3', 'docx', 'pptx'],
        'max_kb' => 307200,
        'max_files' => 1,
        'disk' => 'private',
    ],

    'need_photo' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 5120,
        'max_files' => 4,
        'max_width' => 1600,
        'target_extension' => 'webp',
        'quality' => 85,
    ],

    'site_default_share_image' => [
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kb' => 5120,
        'max_files' => 1,
        'max_width' => 1200,
        'target_extension' => 'webp',
        'quality' => 86,
    ],

    // Imágenes de marca del singleton de configuración del sitio. Se
    // suben tal cual (sin pasar por `MediaUploader`) para preservar SVG.

    'site_login_background' => [
        'mimes' => ['png', 'svg', 'webp'],
        'max_kb' => 5120,
        'max_files' => 1,
    ],

    'site_footer_background' => [
        'mimes' => ['png', 'svg', 'webp', 'jpg', 'jpeg'],
        'max_kb' => 5120,
        'max_files' => 1,
    ],

    'site_apple_touch_icon' => [
        'mimes' => ['png', 'svg', 'webp', 'jpg', 'jpeg'],
        'max_kb' => 1024,
        'max_files' => 1,
    ],

    'site_main_search_background' => [
        'mimes' => ['png', 'svg', 'webp', 'jpg', 'jpeg'],
        'max_kb' => 5120,
        'max_files' => 1,
    ],

    'site_logo' => [
        'mimes' => ['png', 'svg', 'webp'],
        'max_kb' => 1024,
        'max_files' => 1,
    ],

    'site_logo_mono' => [
        'mimes' => ['png', 'svg', 'webp'],
        'max_kb' => 1024,
        'max_files' => 1,
    ],

    'site_create_vitrina_video' => [
        'mimes' => ['mp4', 'webm', 'mov'],
        'max_kb' => 51200,
        'max_files' => 1,
    ],

    'site_pidelo_video' => [
        'mimes' => ['mp4', 'webm', 'mov'],
        'max_kb' => 51200,
        'max_files' => 1,
    ],

];
